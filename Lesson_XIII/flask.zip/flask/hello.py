from flask import Flask, flash, render_template,  request, session
import sqlite3 as sql
import os
app = Flask(__name__)

@app.route('/')
def login():
   return render_template('login.html')

@app.route('/home')
def home():
   return render_template('home.html')

@app.route('/signup',methods = ['POST', 'GET'])
def signup():
  if request.method == 'POST':
      try:
         uname = request.form['uname']
         pword = request.form['pword']
         
         with sql.connect("database.db") as con:
            cur = con.cursor()
            
            #cur.execute("""CREATE TABLE logins(uname, pword)""")
            cur.execute("INSERT INTO logins (uname,pword) VALUES (?,?)",(uname,pword) )
            
            con.commit()
            msg = "User successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         return render_template("result.html",msg = msg)
         con.close()
  else:
    # Handle GET request
    return render_template("signup.html")

@app.route('/login', methods=['POST'])
def do_admin_login():
    u_stmt="SELECT CASE WHEN '"+ request.form['username'] +"' IN (SELECT uname FROM logins) THEN 1 ELSE 0 END"  #uname in logins
    p_stmt="SELECT pword FROM logins WHERE uname = '"+request.form['username']+"'"  # retrieve pwd of uname
    print u_stmt
    with sql.connect("database.db") as con:
      cur = con.cursor()
      pwd = cur.execute(p_stmt)
      uname = cur.execute(u_stmt)
      print uname
      print pwd
      con.commit()
    con.close()

    if request.form['password'] == pwd and uname == 1:
        session['logged_in'] = True     
        flash('right password!')
        return render_template('home.html')
    else:
        flash('wrong password!')
    return home()

@app.route("/logout")
def logout():
    session['logged_in'] = False
    return render_template('login.html')

@app.route('/enternew')
def new_student():
   return render_template('student.html')

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
   msg = ""
   if request.method == 'POST':
      try:
         nm = request.form['nm']
         addr = request.form['add']
         city = request.form['city']
         pin = request.form['pin']
         
         with sql.connect("database.db") as con:
            cur = con.cursor()
            
            #cur.execute("""CREATE TABLE students(name, text, addr, text, city text, pin integer)""")
            cur.execute("INSERT INTO students (name,addr,city,pin) VALUES (?,?,?,?)",(nm,addr,city,pin) )
            
            con.commit()
            msg = "Student successfully added"
      except:
         con.rollback()
         msg = "error in insert operation"
      
      finally:
         return render_template("result.html",msg = msg)
         con.close()

@app.route('/list')
def list():
   con = sql.connect("database.db")
   con.row_factory = sql.Row
   
   cur = con.cursor()
   cur.execute("select * from students")
   
   rows = cur.fetchall();
   return render_template("list.html",rows = rows)


if __name__ == '__main__':
   app.secret_key = os.urandom(12)
   app.run(debug = True)

